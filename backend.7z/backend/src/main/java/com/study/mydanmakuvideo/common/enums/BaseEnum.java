package com.study.mydanmakuvideo.common.enums;

public interface BaseEnum {
    String getDetail();

}
