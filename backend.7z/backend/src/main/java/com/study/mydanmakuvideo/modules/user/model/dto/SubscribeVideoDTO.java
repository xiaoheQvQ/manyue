package com.study.mydanmakuvideo.modules.user.model.dto;

/**
 * 订阅视频DTO
 *
 * @author Mrhe
 */
public class SubscribeVideoDTO {

    private Long userId;
    private String nick;

    private String videoId;
    private String title;
}
