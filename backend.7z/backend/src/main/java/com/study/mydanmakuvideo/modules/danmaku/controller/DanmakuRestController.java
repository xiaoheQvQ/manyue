package com.study.mydanmakuvideo.modules.danmaku.controller;

import com.study.mydanmakuvideo.common.controller.SuperController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 弹幕表 前端控制器
 * </p>
 *
 * @author Mrhe
 * 
 */
@RestController
@RequestMapping("/danmaku/danmaku-entity")
public class DanmakuRestController extends SuperController {

}
