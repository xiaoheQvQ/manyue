package com.hsx.constant;

public interface UserMomentsConstant {

    String GROUP_MOMENTS = "MomentsGroup";

    String GROUP_DANMUS = "DanmusGroup";

    String TOPIC_MOMENTS = "Topic-Moments";

    String TOPIC_DANMUS = "Topic-Danmus";
}
