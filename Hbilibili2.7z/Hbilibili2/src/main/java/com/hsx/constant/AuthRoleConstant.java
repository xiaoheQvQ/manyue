package com.hsx.constant;

public interface AuthRoleConstant {

    String ROLE_LV0 = "Lv0";

    String ROLE_LV1 = "Lv1";

    String ROLE_LV2 = "Lv2";
}
